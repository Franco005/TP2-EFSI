const form = document.getElementById("form");

form.addEventListener("submit", function(event) {
  var notaMate = parseFloat(form.elements["matematica"].value);
  var notaLengua = parseFloat(form.elements["lengua"].value);
  var notaEfsi = parseFloat(form.elements["efsi"].value);

  if(isNaN(notaMate) || isNaN(notaLengua) || isNaN(notaEfsi)){
    alert("Los campos son obligatorios, completa todas tus notas para enviar el formulario.");
  }else if(notaMate > 10 || notaMate < 1 || notaLengua < 1 || notaLengua > 10 || notaEfsi < 1 || notaEfsi > 10){
    alert("Las notas solo pueden ser del 1 al 10, complete correctamente los campos");
  } else {
    var TodasNotas = [notaMate, notaLengua, notaEfsi];
    const nombreMateria = ["Matemática" , "Lengua", "EFSI"]

    function ArrayAvg(TodasNotas) {
      var i = 0;
      var summ = 0;
      while (i < TodasNotas.length) {
        summ = summ + parseFloat(TodasNotas[i++]);
      }
      return summ / TodasNotas.length;
    }

    function calcularMaximo(){
      var NotaMax = Math.max(notaMate, notaLengua, notaEfsi);
      var i = 0;
      while(NotaMax != TodasNotas[i]){
        i++;
      }
      var nombreBuscado = nombreMateria[i];
      var resultado = document.getElementById("resultado");
      resultado.innerHTML = `La nota más alta es: ${nombreBuscado}`;
    }

    function calcularPromedio(){
      var promedio = ArrayAvg(TodasNotas);
      var resultado = document.getElementById("resultado");
      if(promedio > 6){
        resultado.style.color = "green";
      }
      else{
        resultado.style.color = "red";
      }
     
      resultado.innerHTML = `El promedio de notas es: ${promedio}`;
    }

    if (event.submitter.value === "Mayor Nota") {
      calcularMaximo();
    } else {
      calcularPromedio();
    }
  }
  event.preventDefault();
});